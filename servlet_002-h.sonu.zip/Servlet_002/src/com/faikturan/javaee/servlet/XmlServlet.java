package com.faikturan.javaee.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import com.faikturan.javaee.model.Person;
import com.faikturan.javaee.util.PersonStorage;

/**
 * Servlet implementation class XmlServlet
 */
@WebServlet("/xml")
public class XmlServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public XmlServlet() {
        super();
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Person person = PersonStorage.getPersons().get(0);
		
		JAXBContext jaxbContext = null;
		try {
			jaxbContext = JAXBContext.newInstance(Person.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
			
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			
			jaxbMarshaller.marshal(person, response.getWriter());
		} catch (JAXBException e) {
			e.printStackTrace();
		}
		
		
	}

}
