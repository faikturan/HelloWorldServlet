package com.faikturan.javaee.util;

import java.util.ArrayList;
import java.util.List;

import com.faikturan.javaee.model.Address;
import com.faikturan.javaee.model.Person;
import com.faikturan.javaee.model.Phone;

public class PersonStorage {
	
	public static List<Person> getPersons(){
		List<Person> persons = new ArrayList<Person>();
		Person p1 = new Person("Faik", "TURAN", 39);
		Address a1 = new Address("�stanbul", "Merkez", 34530);
		Phone p11 = new Phone("cell", "05369782612");
		Phone p12 = new Phone("work", "2122222222");
		
		p1.setAddress(a1);
		p1.addPhone(p11);
		p1.addPhone(p12);
		
		persons.add(p1);
		
		return persons;
	}

}
