package com.faikturan.javaee.model;

public class Phone {

}
