package com.faikturan.javaee.model;

public class Person {

}
