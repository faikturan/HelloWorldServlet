package com.faikturan.javaee.model;

public class Address {
	private String city;
	private String streer;
	private int zip;
	
	
	public Address(String city, String streer, int zip) {
		this.city = city;
		this.streer = streer;
		this.zip = zip;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public String getStreer() {
		return streer;
	}


	public void setStreer(String streer) {
		this.streer = streer;
	}


	public int getZip() {
		return zip;
	}


	public void setZip(int zip) {
		this.zip = zip;
	}
	
	
	
	

}
