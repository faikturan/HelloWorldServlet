package com.faikturan.servlet.util;

import java.util.ArrayList;
import java.util.List;

import com.faikturan.servlet.model.Address;
import com.faikturan.servlet.model.Person;
import com.faikturan.servlet.model.Phone;

public class PersonStorage {
	
	public static List<Person> getPersons(){
		List<Person> persons = new ArrayList<Person>();
		Person p1 = new Person("Ramazan", "Aba�", 30);
		Address a1 = new Address("�stanbul", "Merkez", 34534);
		Phone p11 = new Phone("cell", "05555555555");
		Phone p12 = new Phone("work", "2122222222");
		
		p1.setAddress(a1);
		p1.addPhone(p11);
		p1.addPhone(p12);
		
		Person p2 = new Person("Mert", "Vatansever", 20);
		Address a2 = new Address("�stanbul", "Vatan", 34555);
		Phone p21 = new Phone("cell", "05444444444");
		Phone p22 = new Phone("work", "2125555555");
		
		p2.setAddress(a2);
		p2.addPhone(p21);
		p2.addPhone(p22);
		
		persons.add(p1);
		persons.add(p2);
		
		return persons;
		
	}

}
